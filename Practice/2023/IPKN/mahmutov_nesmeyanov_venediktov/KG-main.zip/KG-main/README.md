# Knowledge graphs

## Theme
Football world-cup

## Datasets
1. https://www.jokecamp.com/blog/guide-to-football-and-soccer-data-and-apis/
2. https://github.com/openfootball/worldcup

## Pre-Presentation
https://docs.google.com/presentation/d/1a15qmsOWS63XW5nBNisCkTZN0N_cCXRomzDwDGmXaFo/edit#slide=id.p

## Authors
1. Dmitry Nesmeyanov [@smeyanoff](https://github.com/smeyanoff)
2. Nikita Venediktov [@NikitaVenediktov](https://github.com/NikitaVenediktov)
3. Rinat Mahmutov [@talveRinat](https://github.com/talveRinat)
